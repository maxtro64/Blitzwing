import dotenv from "dotenv";
dotenv.config(); 

import express from "express";
import authRoutes from "./routes/authRoutes.js";
import userRouter from "./routes/userRoutes.js";
import dbConnect from "./config/dbConnect.js";

const app = express();

// Middleware
app.use(express.json());

// Routes
app.use("/api/auth", authRoutes);
app.use("/api/users", userRouter);

// Server
const PORT = process.env.PORT || 5001;

// Database connection 
dbConnect(); 

app.listen(PORT, () => {
    console.log(`Server is running at port ${PORT}`);
    
});