const authorizationRoles = (...allowedRoles) => {
    return (req, res, next) => {
       
        if (!req.user || !req.user.role) {
            return res.status(401).json({ 
                success: false,
                message: "Unauthorized - User not authenticated" 
            });
        }

       
        if (!allowedRoles.includes(req.user.role)) {
            return res.status(403).json({ 
                success: false,
                message: "Forbidden - You don't have permission to access this resource" 
            });
        }

        next();
    };
};

export default authorizationRoles;