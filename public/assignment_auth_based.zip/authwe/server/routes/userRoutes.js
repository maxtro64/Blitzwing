import express from "express";
import { verifyToken } from "../middleware/authmiddleware.js";
import authorizationRoles from "../middleware/rolemiddleware.js";
const router = express.Router();

// Admin route - only accessible to admins
router.get("/admin", 
    verifyToken, 
    authorizationRoles('admin'), 
    (req, res) => {
        res.json({ message: "Welcome admin" });
    }
);

//User route
router.get("/user", 
    verifyToken, 
    (req, res) => {
        res.json({ message: "Welcome user" });
    }
);

// Manager route 
router.get("/manager", 
    verifyToken, 
    authorizationRoles('manager'), 
    (req, res) => {
        res.json({ message: "Welcome manager" });
    }
);

// Admin route 
router.get("/admin", 
    verifyToken, 
    authorizationRoles('admin', 'manager'), 
    (req, res) => {
        res.json({ message: "Welcome admin or manager" });
    }
);

export default router;