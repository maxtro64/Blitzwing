import bcrypt from "bcryptjs";
import {User} from "../models/UserSchema.js";
import jwt from "jsonwebtoken";

export const register = async (req, res) => {
    try {
        const { username, password, role } = req.body;
        
        
        const hashpassword = await bcrypt.hash(password, 10);
        const newUser = new User({ username, password: hashpassword, role }); 
    
        await newUser.save(); 
        res.status(201).json({ message: `User is registered with username ${username}` });
        
    } catch (error) {
        res.status(500).json({ message: `Something Went Wrong`, error: error.message });
    }
}

export const login = async (req, res) => {  
    try {
        const { username, password } = req.body; 

        const user = await User.findOne({ username });
        if (!user) {
            return res.status(404).json({ message: `User with username ${username} not found` });
        }

        const isMatch = await bcrypt.compare(password, user.password);
        if (!isMatch) {
            return res.status(400).json({ message: `Invalid Credential` });
        }

        const token = jwt.sign(
            { id: user._id, role: user.role },
            process.env.JWT_SECRET,
            { expiresIn: "1h" }
        );

       
        const userWithoutPassword = user.toObject();
        delete userWithoutPassword.password;

        res.status(200).json({ token, user: userWithoutPassword });

    } catch (error) {
        res.status(500).json({ message: `Something Went Wrong`, error: error.message });
    }
}