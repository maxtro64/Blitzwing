import express from "express";
import { verifyToken } from "../middleware/authmiddleware.js";
import authorizationRoles from "../middleware/rolemiddleware.js";
const router = express.Router();

// Admin route - only accessible to admins
router.get("/admin", 
    verifyToken, 
    authorizationRoles('admin'), 
    (req, res) => {
        res.json({ message: "Welcome admin" });
    }
);

// User route - accessible to all authenticated users
router.get("/user", 
    verifyToken, 
    (req, res) => {
        res.json({ message: "Welcome user" });
    }
);

// Manager route - only accessible to managers
router.get("/manager", 
    verifyToken, 
    authorizationRoles('manager'), 
    (req, res) => {
        res.json({ message: "Welcome manager" });
    }
);

// Manager and Admin route - accessible to both roles
router.get("/admin", 
    verifyToken, 
    authorizationRoles('admin', 'manager'), 
    (req, res) => {
        res.json({ message: "Welcome admin or manager" });
    }
);

export default router;