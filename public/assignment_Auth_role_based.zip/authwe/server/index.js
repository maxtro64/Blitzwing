import dotenv from "dotenv";
dotenv.config(); // This MUST be at the very top

import express from "express";
import authRoutes from "./routes/authRoutes.js";
import userRouter from "./routes/userRoutes.js";
import dbConnect from "./config/dbConnect.js";

const app = express();

// Middleware
app.use(express.json());

// Routes
app.use("/api/auth", authRoutes);
app.use("/api/users", userRouter);

// Server
const PORT = process.env.PORT || 5001;

// Database connection - moved after dotenv.config()
dbConnect(); 

app.listen(PORT, () => {
    console.log(`Server is running at port ${PORT}`);
    console.log("Current NODE_ENV:", process.env.NODE_ENV); // Test if env is loading
});