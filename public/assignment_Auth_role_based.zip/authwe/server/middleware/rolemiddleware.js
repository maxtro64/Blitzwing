const authorizationRoles = (...allowedRoles) => {
    return (req, res, next) => {
        // Check if user exists and has a role
        if (!req.user || !req.user.role) {
            return res.status(401).json({ 
                success: false,
                message: "Unauthorized - User not authenticated" 
            });
        }

        // Check if user's role is included in allowed roles
        if (!allowedRoles.includes(req.user.role)) {
            return res.status(403).json({ 
                success: false,
                message: "Forbidden - You don't have permission to access this resource" 
            });
        }

        next();
    };
};

export default authorizationRoles;