import mongoose from "mongoose";


const dbConnect=async()=>{


    try {
        console.log(process.env.conn)
        const connect =await mongoose.connect(process.env.CONNNECTION_STRING);
      
        console.log(`Database connected :${connect.connection.hostname,connect.connection.name}`)
    } catch (err) {
        console.log(err);
        process.exit(1);

    }

} 

export default dbConnect;